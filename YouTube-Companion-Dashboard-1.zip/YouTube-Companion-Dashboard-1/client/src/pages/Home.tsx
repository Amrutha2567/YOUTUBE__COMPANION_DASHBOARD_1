import { Link } from "wouter";
import { ArrowRight, LayoutDashboard, Search, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Home() {
  const [searchId, setSearchId] = useState("");

  // Mock videos for demonstration since we don't have a list endpoint
  const recentVideos = [
    { id: 1, title: "Getting Started with React 18", views: "12.5k", date: "2 days ago" },
    { id: 2, title: "Advanced TypeScript Patterns", views: "8.2k", date: "5 days ago" },
    { id: 3, title: "Building a SaaS in 2025", views: "45k", date: "1 week ago" },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background relative overflow-hidden p-6">
      {/* Abstract Background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl -z-10" />
      
      <div className="w-full max-w-2xl mx-auto text-center space-y-8">
        <div className="space-y-4">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
            <LayoutDashboard className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tighter text-foreground">
            YouTube Companion
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-lg mx-auto leading-relaxed">
            Manage your content, engage with comments, and optimize titles with AI-powered tools.
          </p>
        </div>

        <div className="p-1.5 bg-card border rounded-2xl shadow-xl shadow-black/5 flex items-center gap-2 max-w-md mx-auto">
          <Input 
            placeholder="Enter Video ID..." 
            className="border-0 bg-transparent focus-visible:ring-0 text-base h-12"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
          />
          <Link href={searchId ? `/video/${searchId}` : "#"}>
            <Button size="icon" className="h-10 w-10 rounded-xl shrink-0" disabled={!searchId}>
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>

        <div className="pt-12">
          <p className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-6">Recent Projects</p>
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 text-left">
            {recentVideos.map((video) => (
              <Link key={video.id} href={`/video/${video.id}`}>
                <div className="group p-4 rounded-xl bg-card border hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <Video className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-primary transition-colors">{video.title}</h3>
                  <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                    <span>{video.views} views</span>
                    <span>•</span>
                    <span>{video.date}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

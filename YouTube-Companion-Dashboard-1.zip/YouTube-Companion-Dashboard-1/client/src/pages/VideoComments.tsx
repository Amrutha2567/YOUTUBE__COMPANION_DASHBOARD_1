import { useParams } from "wouter";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useComments, useReplyToComment } from "@/hooks/use-comments";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, Reply, ThumbsUp, CornerDownRight, Loader2 } from "lucide-react";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";

export default function VideoComments() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  const { data: comments, isLoading } = useComments(videoId);

  return (
    <DashboardLayout videoId={videoId}>
      <div className="space-y-8">
        <header>
          <h2 className="text-3xl font-display font-bold">Comments</h2>
          <p className="text-muted-foreground">Engage with your community.</p>
        </header>

        <div className="space-y-4 max-w-3xl">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : comments?.length === 0 ? (
            <div className="text-center py-12 border rounded-2xl bg-muted/20">
              <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold">No comments yet</h3>
              <p className="text-muted-foreground">Be the first to start the conversation!</p>
            </div>
          ) : (
            comments?.map((comment) => (
              <CommentItem key={comment.id} comment={comment} />
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

function CommentItem({ comment }: { comment: any }) {
  const [isReplying, setIsReplying] = useState(false);
  const [replyText, setReplyText] = useState("");
  const { mutate: reply, isPending } = useReplyToComment();

  const handleReply = () => {
    if (!replyText.trim()) return;
    reply({ commentId: comment.id, text: replyText }, {
      onSuccess: () => {
        setIsReplying(false);
        setReplyText("");
      }
    });
  };

  return (
    <Card className="p-6 transition-all hover:border-primary/20">
      <div className="flex gap-4">
        <Avatar className="w-10 h-10 border">
          <AvatarImage src={comment.authorAvatarUrl || undefined} />
          <AvatarFallback>{comment.authorName[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-semibold">{comment.authorName}</span>
              <span className="text-xs text-muted-foreground">
                {comment.publishedAt ? formatDistanceToNow(new Date(comment.publishedAt), { addSuffix: true }) : ''}
              </span>
            </div>
          </div>
          
          <p className="text-sm leading-relaxed text-foreground/90">{comment.textDisplay}</p>

          <div className="flex items-center gap-4 pt-2">
            <button className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors">
              <ThumbsUp className="w-3.5 h-3.5" /> Like
            </button>
            <button 
              onClick={() => setIsReplying(!isReplying)}
              className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              <Reply className="w-3.5 h-3.5" /> Reply
            </button>
          </div>

          {isReplying && (
            <div className="mt-4 flex gap-3 animate-in slide-in-from-top-2 fade-in duration-200">
              <div className="w-8 flex justify-center">
                <CornerDownRight className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex-1 space-y-3">
                <Textarea 
                  placeholder="Write a public reply..." 
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="min-h-[80px] bg-muted/30"
                />
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setIsReplying(false)}>Cancel</Button>
                  <Button size="sm" onClick={handleReply} disabled={isPending || !replyText.trim()}>
                    {isPending ? "Posting..." : "Reply"}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

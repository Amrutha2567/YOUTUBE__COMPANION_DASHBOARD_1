import { useParams } from "wouter";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useSuggestions, useGenerateSuggestions } from "@/hooks/use-suggestions";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sparkles, Copy, Check, Wand2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function VideoAI() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  const { data: suggestions, isLoading } = useSuggestions(videoId);
  const { mutate: generate, isPending } = useGenerateSuggestions();
  const { toast } = useToast();
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const handleCopy = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast({ title: "Copied!", description: "Title copied to clipboard." });
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <DashboardLayout videoId={videoId}>
      <div className="space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-display font-bold flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" /> AI Tools
            </h2>
            <p className="text-muted-foreground">Generate viral titles and optimize your content.</p>
          </div>
          <Button 
            onClick={() => generate({ videoId })} 
            disabled={isPending}
            className="gap-2 bg-gradient-to-r from-primary to-orange-500 hover:from-primary/90 hover:to-orange-500/90 text-white border-0 shadow-lg shadow-primary/20"
          >
            <Wand2 className={`w-4 h-4 ${isPending ? 'animate-spin' : ''}`} />
            {isPending ? "Generating..." : "Generate New Ideas"}
          </Button>
        </header>

        <div className="grid gap-4">
          {isLoading ? (
             <div className="space-y-4">
               {[1,2,3].map(i => <div key={i} className="h-20 bg-muted/50 rounded-xl animate-pulse" />)}
             </div>
          ) : suggestions?.length === 0 ? (
            <Card className="p-12 text-center bg-gradient-to-br from-card to-muted border-dashed">
              <Sparkles className="w-16 h-16 text-primary/20 mx-auto mb-6" />
              <h3 className="text-xl font-bold mb-2">No AI suggestions yet</h3>
              <p className="text-muted-foreground max-w-sm mx-auto mb-8">
                Let our AI analyze your content and suggest catchy, high-performing titles.
              </p>
              <Button onClick={() => generate({ videoId })} size="lg">Generate First Batch</Button>
            </Card>
          ) : (
            suggestions?.map((suggestion) => (
              <Card 
                key={suggestion.id} 
                className="p-4 flex items-center justify-between group hover:border-primary/50 hover:bg-primary/5 transition-all duration-300"
              >
                <span className="text-lg font-medium">{suggestion.suggestion}</span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="gap-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => handleCopy(suggestion.suggestion, suggestion.id)}
                >
                  {copiedId === suggestion.id ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  {copiedId === suggestion.id ? "Copied" : "Copy"}
                </Button>
              </Card>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

import { useParams } from "wouter";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useNotes, useCreateNote, useDeleteNote } from "@/hooks/use-notes";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, StickyNote, Loader2 } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

export default function VideoNotes() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  const { data: notes, isLoading } = useNotes(videoId);
  const { mutate: addNote, isPending: isAdding } = useCreateNote();
  const { mutate: deleteNote, isPending: isDeleting } = useDeleteNote();
  const [newNote, setNewNote] = useState("");

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    addNote({ videoId, content: newNote }, {
      onSuccess: () => setNewNote("")
    });
  };

  return (
    <DashboardLayout videoId={videoId}>
      <div className="space-y-8">
        <header>
          <h2 className="text-3xl font-display font-bold">Notes</h2>
          <p className="text-muted-foreground">Keep track of ideas and tasks for this video.</p>
        </header>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Create Note */}
          <div>
            <Card className="p-6 sticky top-6 bg-card border-primary/20 shadow-lg shadow-primary/5">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-primary" /> New Note
              </h3>
              <Textarea 
                placeholder="What's on your mind? (e.g., Update thumbnail, Reply to top comment...)" 
                className="min-h-[150px] mb-4 resize-none text-base"
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
              />
              <Button 
                className="w-full" 
                onClick={handleAddNote} 
                disabled={isAdding || !newNote.trim()}
              >
                {isAdding ? "Adding..." : "Add Note"}
              </Button>
            </Card>
          </div>

          {/* Notes List */}
          <div className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : notes?.length === 0 ? (
              <div className="text-center py-12 border rounded-2xl border-dashed">
                <StickyNote className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">No notes yet.</p>
              </div>
            ) : (
              notes?.map((note) => (
                <Card key={note.id} className="p-5 group hover:border-primary/40 transition-colors">
                  <div className="flex justify-between items-start gap-4">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap flex-1">{note.content}</p>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive"
                      onClick={() => deleteNote({ id: note.id, videoId })}
                      disabled={isDeleting}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="mt-4 pt-4 border-t flex justify-between items-center text-xs text-muted-foreground">
                    <span>{note.createdAt ? format(new Date(note.createdAt), "PPP") : "Just now"}</span>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

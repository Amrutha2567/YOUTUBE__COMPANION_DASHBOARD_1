import { useParams } from "wouter";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useVideo, useUpdateVideo, useSyncVideo } from "@/hooks/use-videos";
import { StatCard } from "@/components/StatCard";
import { Eye, ThumbsUp, MessageCircle, RefreshCw, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useForm } from "react-hook-form";
import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";

export default function VideoOverview() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  const { data: video, isLoading } = useVideo(videoId);
  const { mutate: updateVideo, isPending: isUpdating } = useUpdateVideo(videoId);
  const { mutate: syncVideo, isPending: isSyncing } = useSyncVideo(videoId);

  const { register, handleSubmit, reset, formState: { isDirty } } = useForm({
    defaultValues: {
      title: "",
      description: "",
    }
  });

  useEffect(() => {
    if (video) {
      reset({
        title: video.title,
        description: video.description || "",
      });
    }
  }, [video, reset]);

  const onSubmit = (data: { title: string; description: string }) => {
    updateVideo(data);
  };

  if (isLoading) return <OverviewSkeleton />;
  if (!video) return <NotFoundState />;

  return (
    <DashboardLayout videoId={videoId}>
      <div className="space-y-8">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold">Overview</h2>
            <p className="text-muted-foreground">Manage your video metadata and performance.</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground mr-2">
              Last synced: {video.lastSyncedAt ? formatDistanceToNow(new Date(video.lastSyncedAt), { addSuffix: true }) : 'Never'}
            </span>
            <Button 
              variant="outline" 
              onClick={() => syncVideo()} 
              disabled={isSyncing}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              Sync Stats
            </Button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard 
            label="Total Views" 
            value={video.viewCount?.toLocaleString() || "0"} 
            icon={Eye} 
            trend="+12%" 
            trendUp={true} 
          />
          <StatCard 
            label="Likes" 
            value={video.likeCount?.toLocaleString() || "0"} 
            icon={ThumbsUp} 
          />
          <StatCard 
            label="Comments" 
            value={video.commentCount?.toLocaleString() || "0"} 
            icon={MessageCircle} 
          />
        </div>

        {/* Main Content Area */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Metadata Form */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-border/50 shadow-sm">
              <CardHeader>
                <CardTitle>Video Details</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Title</label>
                    <Input 
                      {...register("title")} 
                      className="text-lg font-semibold" 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Description</label>
                    <Textarea 
                      {...register("description")} 
                      className="min-h-[200px] font-mono text-sm leading-relaxed" 
                    />
                  </div>

                  <div className="flex justify-end pt-4">
                    <Button 
                      type="submit" 
                      disabled={!isDirty || isUpdating}
                      className="min-w-[120px] gap-2"
                    >
                      {isUpdating ? "Saving..." : <><Save className="w-4 h-4" /> Save Changes</>}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Video Preview */}
          <div className="space-y-6">
            <Card className="overflow-hidden border-border/50 shadow-sm sticky top-6">
              <div className="aspect-video bg-black relative group">
                {video.thumbnailUrl ? (
                  <img 
                    src={video.thumbnailUrl} 
                    alt={video.title} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                    No Thumbnail
                  </div>
                )}
                {/* Overlay Play Button */}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center pl-1">
                      <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-black border-b-[8px] border-b-transparent" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-semibold line-clamp-2 mb-2">{video.title}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="bg-muted px-2 py-0.5 rounded text-xs font-medium">HD</span>
                  <span>{video.youtubeId}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

function OverviewSkeleton() {
  return (
    <div className="p-8 space-y-8 max-w-5xl mx-auto">
      <div className="flex justify-between">
        <div className="space-y-2">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        {[1,2,3].map(i => <Skeleton key={i} className="h-32 rounded-2xl" />)}
      </div>
      <div className="grid lg:grid-cols-3 gap-8">
        <Skeleton className="lg:col-span-2 h-96 rounded-2xl" />
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    </div>
  );
}

function NotFoundState() {
  return (
    <div className="min-h-screen flex items-center justify-center flex-col gap-4">
      <h2 className="text-2xl font-bold">Video Not Found</h2>
      <Button asChild><Link href="/">Go Home</Link></Button>
    </div>
  );
}

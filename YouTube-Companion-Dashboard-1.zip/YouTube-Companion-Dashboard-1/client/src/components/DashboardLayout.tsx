import { Link, useRoute } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  MessageSquare, 
  NotebookPen, 
  Sparkles, 
  Youtube,
  Menu,
  ChevronLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { useVideo } from "@/hooks/use-videos";

interface DashboardLayoutProps {
  children: React.ReactNode;
  videoId: number;
}

export function DashboardLayout({ children, videoId }: DashboardLayoutProps) {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { data: video } = useVideo(videoId);

  const navItems = [
    { label: "Overview", icon: LayoutDashboard, href: `/video/${videoId}` },
    { label: "Comments", icon: MessageSquare, href: `/video/${videoId}/comments` },
    { label: "Notes", icon: NotebookPen, href: `/video/${videoId}/notes` },
    { label: "AI Tools", icon: Sparkles, href: `/video/${videoId}/ai` },
  ];

  const Navigation = () => {
    const [location] = useRoute("/video/:id/*?");
    // Manually reconstruct current path to check active state
    const currentPath = window.location.pathname;

    return (
      <div className="flex flex-col h-full py-6">
        <div className="px-6 mb-8">
          <Link href="/" className="flex items-center gap-2 mb-6 text-muted-foreground hover:text-foreground transition-colors group">
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to Home
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
              <Youtube className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-display font-bold text-lg leading-tight line-clamp-1">
                {video?.title || "Loading..."}
              </h1>
              <p className="text-xs text-muted-foreground font-medium">Dashboard</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          {navItems.map((item) => {
            const isActive = currentPath === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group cursor-pointer",
                    isActive 
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                  onClick={() => setIsMobileOpen(false)}
                >
                  <item.icon className={cn("w-5 h-5", isActive ? "text-primary-foreground" : "text-muted-foreground group-hover:text-foreground")} />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="px-6 mt-auto">
          <div className="p-4 rounded-xl bg-gradient-to-br from-card to-muted border shadow-sm">
            <p className="text-xs font-medium text-muted-foreground mb-1">Channel Status</p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-sm font-bold">Active</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-72 border-r bg-card/50 backdrop-blur-xl fixed inset-y-0 z-30">
        <Navigation />
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 border-b bg-background/80 backdrop-blur-md z-40 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Youtube className="w-6 h-6 text-primary" />
          <span className="font-display font-bold">Studio</span>
        </div>
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <Navigation />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-72 pt-16 md:pt-0 min-h-screen relative overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-96 bg-primary/5 -z-10 pointer-events-none" />
        <div className="max-w-5xl mx-auto p-4 md:p-8 lg:p-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}

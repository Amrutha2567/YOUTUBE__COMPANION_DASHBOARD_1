import { cn } from "@/lib/utils";
import { DivideIcon as LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
  className?: string;
}

export function StatCard({ label, value, icon: Icon, trend, trendUp, className }: StatCardProps) {
  return (
    <div className={cn(
      "p-6 rounded-2xl bg-card border shadow-sm hover:shadow-md transition-all duration-300 group",
      className
    )}>
      <div className="flex items-center justify-between mb-4">
        <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary/10 group-hover:scale-110 transition-all duration-300">
          <Icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
        {trend && (
          <div className={cn(
            "text-xs font-bold px-2 py-1 rounded-full",
            trendUp ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-500"
          )}>
            {trend}
          </div>
        )}
      </div>
      <div>
        <h3 className="text-2xl font-display font-bold text-foreground tracking-tight">{value}</h3>
        <p className="text-sm text-muted-foreground font-medium mt-1">{label}</p>
      </div>
    </div>
  );
}

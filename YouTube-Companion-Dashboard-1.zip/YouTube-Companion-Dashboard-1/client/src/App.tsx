import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "@/pages/Home";
import VideoOverview from "@/pages/VideoOverview";
import VideoComments from "@/pages/VideoComments";
import VideoNotes from "@/pages/VideoNotes";
import VideoAI from "@/pages/VideoAI";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/video/:id" component={VideoOverview} />
      <Route path="/video/:id/comments" component={VideoComments} />
      <Route path="/video/:id/notes" component={VideoNotes} />
      <Route path="/video/:id/ai" component={VideoAI} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

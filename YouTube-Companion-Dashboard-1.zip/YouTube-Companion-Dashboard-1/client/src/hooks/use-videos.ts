import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { type InsertVideo } from "@shared/schema";

export function useVideo(id: number) {
  return useQuery({
    queryKey: [api.video.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.video.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch video");
      return api.video.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useUpdateVideo(id: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (updates: Partial<InsertVideo>) => {
      const url = buildUrl(api.video.update.path, { id });
      const res = await fetch(url, {
        method: api.video.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update video");
      return api.video.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.video.get.path, id] });
      toast({ title: "Success", description: "Video updated successfully" });
    },
    onError: (error) => {
      toast({ 
        title: "Error", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });
}

export function useSyncVideo(id: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const url = buildUrl(api.video.sync.path, { id });
      const res = await fetch(url, {
        method: api.video.sync.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to sync video stats");
      return api.video.sync.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.video.get.path, id] });
      toast({ title: "Synced", description: "Latest stats retrieved from YouTube" });
    },
  });
}

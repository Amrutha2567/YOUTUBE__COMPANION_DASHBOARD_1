import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { type InsertNote } from "@shared/schema";

export function useNotes(videoId: number) {
  return useQuery({
    queryKey: [api.notes.list.path, videoId],
    queryFn: async () => {
      const url = buildUrl(api.notes.list.path, { videoId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch notes");
      return api.notes.list.responses[200].parse(await res.json());
    },
    enabled: !!videoId,
  });
}

export function useCreateNote() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (note: InsertNote) => {
      const res = await fetch(api.notes.create.path, {
        method: api.notes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(note),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create note");
      return api.notes.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.notes.list.path, variables.videoId] });
      toast({ title: "Note Added", description: "Your note has been saved." });
    },
  });
}

export function useDeleteNote() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, videoId }: { id: number; videoId: number }) => {
      const url = buildUrl(api.notes.delete.path, { id });
      const res = await fetch(url, {
        method: api.notes.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete note");
    },
    onSuccess: (_, { videoId }) => {
      queryClient.invalidateQueries({ queryKey: [api.notes.list.path, videoId] });
      toast({ title: "Note Deleted", description: "The note was removed." });
    },
  });
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSuggestions(videoId: number) {
  return useQuery({
    queryKey: [api.suggestions.list.path, videoId],
    queryFn: async () => {
      const url = buildUrl(api.suggestions.list.path, { videoId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch suggestions");
      return api.suggestions.list.responses[200].parse(await res.json());
    },
    enabled: !!videoId,
  });
}

export function useGenerateSuggestions() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ videoId }: { videoId: number }) => {
      const url = buildUrl(api.suggestions.generate.path, { videoId });
      const res = await fetch(url, {
        method: api.suggestions.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ count: 5 }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate suggestions");
      return api.suggestions.generate.responses[200].parse(await res.json());
    },
    onSuccess: (_, { videoId }) => {
      queryClient.invalidateQueries({ queryKey: [api.suggestions.list.path, videoId] });
      toast({ title: "Ideas Generated", description: "New title ideas are ready for review." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate ideas. Try again.", variant: "destructive" });
    },
  });
}

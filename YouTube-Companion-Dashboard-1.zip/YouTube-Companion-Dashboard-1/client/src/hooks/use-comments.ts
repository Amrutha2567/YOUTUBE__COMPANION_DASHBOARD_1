import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useComments(videoId: number) {
  return useQuery({
    queryKey: [api.comments.list.path, videoId],
    queryFn: async () => {
      const url = buildUrl(api.comments.list.path, { videoId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch comments");
      return api.comments.list.responses[200].parse(await res.json());
    },
    enabled: !!videoId,
  });
}

export function useReplyToComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ commentId, text }: { commentId: number; text: string }) => {
      // NOTE: Using a URL that matches the route manifest, need to cast commentId
      const url = buildUrl(api.comments.reply.path, { commentId });
      const res = await fetch(url, {
        method: api.comments.reply.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to post reply");
      return api.comments.reply.responses[201].parse(await res.json());
    },
    onSuccess: (_, { commentId }) => {
      // In a real app we'd optimistically update, but here we just refetch
      // Since comments list is by videoId, we might need to invalidate widely or pass videoId
      queryClient.invalidateQueries({ queryKey: [api.comments.list.path] });
      toast({ title: "Reply Sent", description: "Your reply has been posted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Could not post reply", variant: "destructive" });
    },
  });
}

## Packages
framer-motion | Smooth layout transitions and micro-interactions
date-fns | Formatting timestamps (e.g., "2 hours ago")
clsx | Conditional class names utility
tailwind-merge | Merging Tailwind classes safely

## Notes
- Tailwind config should extend colors for 'youtube-red' (#FF0000) and dark mode surfaces.
- Using 'Inter' for body text and 'Oswald' or 'Roboto Condensed' for headers/stats to match YouTube aesthetic.
- Video ID parameter expected in routes: /video/:id/*
- Mock data will be used where API endpoints might return 404/empty during initial dev.

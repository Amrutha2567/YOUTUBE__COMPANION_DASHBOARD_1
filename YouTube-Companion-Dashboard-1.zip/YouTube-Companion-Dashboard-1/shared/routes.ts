import { z } from 'zod';
import { insertVideoSchema, insertNoteSchema, videos, notes, comments, titleSuggestions } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  video: {
    get: {
      method: 'GET' as const,
      path: '/api/videos/:id',
      responses: {
        200: z.custom<typeof videos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/videos/:id',
      input: insertVideoSchema.partial(),
      responses: {
        200: z.custom<typeof videos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    sync: { // Sync with YouTube
      method: 'POST' as const,
      path: '/api/videos/:id/sync',
      responses: {
        200: z.custom<typeof videos.$inferSelect>(),
      },
    },
  },
  comments: {
    list: {
      method: 'GET' as const,
      path: '/api/videos/:videoId/comments',
      responses: {
        200: z.array(z.custom<typeof comments.$inferSelect>()),
      },
    },
    reply: {
      method: 'POST' as const,
      path: '/api/comments/:commentId/reply',
      input: z.object({ text: z.string() }),
      responses: {
        201: z.custom<typeof comments.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  notes: {
    list: {
      method: 'GET' as const,
      path: '/api/videos/:videoId/notes',
      responses: {
        200: z.array(z.custom<typeof notes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/notes',
      input: insertNoteSchema,
      responses: {
        201: z.custom<typeof notes.$inferSelect>(),
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/notes/:id',
      responses: {
        204: z.void(),
      },
    },
  },
  suggestions: {
    generate: {
      method: 'POST' as const,
      path: '/api/videos/:videoId/suggestions',
      input: z.object({
        count: z.number().default(5),
      }),
      responses: {
        200: z.array(z.custom<typeof titleSuggestions.$inferSelect>()),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/videos/:videoId/suggestions',
      responses: {
        200: z.array(z.custom<typeof titleSuggestions.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

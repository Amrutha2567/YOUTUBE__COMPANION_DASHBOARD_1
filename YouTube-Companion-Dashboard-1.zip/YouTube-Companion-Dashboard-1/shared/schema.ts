import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Export chat models from integration
export * from "./models/chat";

// === TABLE DEFINITIONS ===

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  youtubeId: text("youtube_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  thumbnailUrl: text("thumbnail_url"),
  viewCount: integer("view_count").default(0),
  likeCount: integer("like_count").default(0),
  commentCount: integer("comment_count").default(0),
  lastSyncedAt: timestamp("last_synced_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  youtubeId: text("youtube_id").unique(),
  videoId: integer("video_id").references(() => videos.id),
  authorName: text("author_name").notNull(),
  authorAvatarUrl: text("author_avatar_url"),
  textDisplay: text("text_display").notNull(),
  publishedAt: timestamp("published_at"),
  isReply: boolean("is_reply").default(false),
  parentId: text("parent_id"), // If it's a reply
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const titleSuggestions = pgTable("title_suggestions", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").references(() => videos.id),
  suggestion: text("suggestion").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isApplied: boolean("is_applied").default(false),
});

// === SCHEMAS ===

export const insertVideoSchema = createInsertSchema(videos).omit({ id: true, lastSyncedAt: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true });
export const insertNoteSchema = createInsertSchema(notes).omit({ id: true, createdAt: true });
export const insertSuggestionSchema = createInsertSchema(titleSuggestions).omit({ id: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Note = typeof notes.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;

export type TitleSuggestion = typeof titleSuggestions.$inferSelect;
export type InsertTitleSuggestion = z.infer<typeof insertSuggestionSchema>;

// Request Types
export type UpdateVideoRequest = Partial<InsertVideo>;
export type CreateNoteRequest = InsertNote;
export type UpdateNoteRequest = Partial<InsertNote>;
export type ReplyCommentRequest = { text: string; parentId: string };
export type GenerateTitlesRequest = { videoId: number; currentTitle: string; description: string };

// Response Types
export type VideoResponse = Video;
export type CommentResponse = Comment;
export type NoteResponse = Note;
export type TitleSuggestionResponse = TitleSuggestion;
